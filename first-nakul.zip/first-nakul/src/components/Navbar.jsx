import {NavLink} from 'react-router-dom'
import './Navbar.css'
export default function Navbar(){
  return(
    <div className='navbar-custom'>
      <ul>
        <li>
          <NavLink to='/' activeclassname='active'>home</NavLink>
        </li>
        <li>
          <NavLink to='/mycart' activeclassname='active'>myCart</NavLink>
        </li>
        <li>
          <NavLink to='/aboutus' activeclassname='active'>Aboutus</NavLink>
        </li>
        <li>
          <NavLink to='/contactus' activeclassname='active'>contactus</NavLink>
        </li>
        <li>
          <NavLink to='/logout' activeclassname='active'>logout</NavLink>
        </li>
        
      </ul>

    
    </div>
    )
}