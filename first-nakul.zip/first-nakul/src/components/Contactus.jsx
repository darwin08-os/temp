import React from 'react'
import './contactus.css'
export default function Contactus() {
  return (
    
      <div className="contact">
        <div className='container'>

        <h1>Contact Us</h1>
        <p>If you have any questions, feel free to reach out to us. We are here to help you!</p>
        <div class="contact-info">
            <p><strong>Email:</strong> <a href="mailto:nakul@123.gmail.com">nakul@123.gmail.com</a></p>
        </div>
         </div>
    
    </div>
  )
}
