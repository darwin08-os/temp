import React, { useEffect, useState } from 'react'
import './aboutus.css'
export default function Aboutus() {

    

  return (
    <div className='about'>
      <div class="container">
        <h1>About Us</h1>
        <p>Welcome to our electronic shopping website, your go-to destination for the latest gadgets and accessories. We are committed to providing high-quality products at the best prices. Our goal is to ensure customer satisfaction with top-notch service.</p>
        <p>Founded by <strong>Nakul Dhrangadhariya</strong>, our store is dedicated to innovation and excellence.</p>
    </div>
    </div>
  )
}
