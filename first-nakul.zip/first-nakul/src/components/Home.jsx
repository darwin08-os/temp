import data from '../Data.json'
import './Home.css'
import {useNavigate} from 'react-router-dom'
export default function Home(props){
  const x = useNavigate()
  const handleSubmit=(index)=>{
    const product = data[index]
    const productName = product.title
    let cart = JSON.parse(localStorage.getItem('laptopshoppy')) || []
    let existingProduct = cart.find((item)=>item.title === productName)
    if(existingProduct){
      existingProduct.quantity += 1
    }
    else{
      cart.push({...product,quantity:1})
    }
    localStorage.setItem('laptopshoppy',JSON.stringify(cart))
    
    alert(`${productName} had been added to cart`)
    
    if(window.confirm("Are you sure want to purchase?")){
      x('/mycart')
    }
  }
  return(
    <div className='Home'>
       
        {data.map((obj,index)=>{
          return <div key={index} className='images'>
          <img  src={require(`.${obj.url}`)} key={index} width='300px' height='310px' alt='' />
          <p>{obj.title}</p>
          <p>{obj.price}</p>
          <button onClick={()=>handleSubmit(index)} className='btn btn-primary'>Add to cart</button>
        </div>
      })}
     
    </div>
    )
}