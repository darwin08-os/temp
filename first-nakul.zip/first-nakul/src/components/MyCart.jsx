import {react, useEffect, useState} from 'react'
import './mycart.css'
import html2pdf from 'html2pdf.js'
export default function MyCart(){

  const [laptop,setLaptop] = useState(JSON.parse(localStorage.getItem('laptopshoppy')))
  const [total,setTotal] = useState(0)


  const countTotal=()=>{
    let price = 0
    let pricearr = laptop.map((obj)=>{
      return obj.price * obj.quantity
    })
    for(let i=0; i < pricearr.length;i++){
      price += pricearr[i]
    }
    setTotal(price)
  }

  const handleBillDownload=()=>{
    const element = document.querySelector('#bill')
    html2pdf(element,{
      margin:20
    });
  }

  useEffect(()=>{
    if(localStorage.getItem('laptopshoppy')){
      let items =  JSON.parse(localStorage.getItem('laptopshoppy')) 
      setLaptop(items)
      countTotal()
    }
  },[localStorage.getItem('laptopshoppy')])

  return(
    <div className='mycart'>
    {!laptop? <p>add item first</p> :  
    <>
    <div className='mycart-content'>
      {/* <div className='products'>
      {laptop.map((obj,index)=>{
        return <div key={index}>
          <img src={require(`.${obj.url}`)} width={'100px'} />
          <p>{obj.price}</p>
          <p>{obj.title}</p>
        </div>
      })}
      </div> */}
<div className='bill' id='bill' style={{padding:'20px'}}>
  <h1>invoice</h1>
  <div style={{display:'flex',alignItems:'end',marginLeft:'5px'}}>
    <div>
  <p>name : <b>{JSON.parse(localStorage.getItem('login')).username}</b></p>  
  <p>amount to pay : <b>{total}</b></p> 
    </div>
    <div>
    <button  onClick={handleBillDownload} className='btn btn-primary m-2' data-html2canvas-ignore>download Bill</button>
    </div>
  </div>
  <table border={'1px solid black'} >
   
    <tr>
      <th></th>
      <th>Title</th>
      <th>Item</th>
      <th>Price</th>
      <th>Quantity</th>
    </tr>
    {laptop.map((obj,index)=>{
    return <>  <tr>
      <td>{index+1}</td>
      <td>{obj.title}</td>
      <td> <img src={require(`.${obj.url}`)} width={'50px'}  alt="" /></td>
      <td>{obj.price * obj.quantity}</td>
      <td>{obj.quantity}</td>
    </tr>
  </>
  
   })}
   <tr className='total'>
    <td colSpan={2}><b>Total Price </b></td>
    <td> <b> {total} </b> </td>
    <td></td>
  </tr>
  </table>
</div>
    </div>
 
</>


    }    
    </div>
    )
}