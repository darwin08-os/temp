import React from 'react';
import './contactus.css';

export default function Contactus() {
  return (
    <div className="contact">
      <div className="container">
        <h1>Contact Us</h1>
        <p>If you have any questions, suggestions, or need support, don't hesitate to reach out. We're here to help you every step of the way.</p>

        <div className="contact-info">
          <p><strong>Email:</strong> <a href="mailto:prince.kavar@laptopshoppy.com">prince.kavar@laptopshoppy.com</a></p>
          <p><strong>Phone:</strong> +91 98765 43210</p>
          <p><strong>Address:</strong> LaptopShoppy HQ, Techno Park, Rajkot, Gujarat - 360001</p>
        </div>

        <div className="contact-footer">
          <p>— Prince Kavar</p>
          <p className="role">Founder & CEO, LaptopShoppy</p>
        </div>
      </div>
    </div>
  );
}
