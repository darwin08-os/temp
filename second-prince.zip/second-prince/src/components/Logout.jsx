import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Logout.css';

export default function Logout(props) {
    const x = useNavigate();
    const [user, setUser] = useState(null);

    useEffect(() => {
        const loggedInUser = JSON.parse(localStorage.getItem('login'));
        if (loggedInUser) {
            setUser(loggedInUser);
        }
    }, []);

    const handleLogout=()=>{
        props.logout();
        x('/');
    }

    return (
        <div className="logout-container">
            <div className="logout-box">
                <h1>visit again, {user ? user.username : 'Guest'} 😇</h1>
                <button className="logout-button" onClick={handleLogout}>Logout</button>
            </div>
        </div>
    );
}