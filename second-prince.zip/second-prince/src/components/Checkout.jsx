import React, { useEffect, useState } from "react";
import "./checkout.css";

export default function Checkout() {
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem("laptopshoppy"));
    if (data) {
      setItems(data);
      let price = 0;
      data.forEach((item) => {
        price += item.price * item.quantity;
      });
      setTotal(price);
    }
  }, []);

  return (
    <div className="checkout">
      <h1 className="heading">Checkout Page</h1>

      {items.length === 0 ? (
        <p className="empty-msg">Your cart is empty.</p>
      ) : (
        <div className="checkout-content">
          <div className="checkout-left">
            <h2>Order Summary</h2>
            {items.map((item, index) => (
              <div key={index} className="item">
                <img
                  src={require(`.${item.url}`)}
                  alt={item.title}
                  className="item-img"
                />
                <div className="item-details">
                  <p className="item-title">{item.title}</p>
                  <p>₹{item.price} × {item.quantity}</p>
                  <p className="item-subtotal">Subtotal: ₹{item.price * item.quantity}</p>
                </div>
              </div>
            ))}
            <div className="checkout-total">
              <h3>Total Amount: ₹{total}</h3>
            </div>
          </div>

          <div className="checkout-right">
            <h2>Billing Info</h2>
            <form>
              <label>Full Name</label>
              <input type="text" required />

              <label>Email</label>
              <input type="email" required />

              <label>Shipping Address</label>
              <textarea rows="3" required />

              <label>Card Number</label>
              <input type="text" placeholder="1234-5678-9012-3456" required />

              <div className="input-row">
                <div>
                  <label>Expiry</label>
                  <input type="text" placeholder="MM/YY" required />
                </div>
                <div>
                  <label>CVV</label>
                  <input type="text" placeholder="123" required />
                </div>
              </div>

              <button type="submit">Pay ₹{total}</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
