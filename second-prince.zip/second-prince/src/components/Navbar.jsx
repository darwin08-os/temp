import { NavLink } from 'react-router-dom';
import './Navbar.css';

export default function Navbar() {
  return (
    <nav className="navbar-custom">
      <div className="nav-left">
        <NavLink to="/" activeclassname="active">Home</NavLink>
      </div>

      <div className="nav-center">
        <h2 className="brand">Laptop Shoppy</h2>
      </div>

      <div className="nav-right">
        <NavLink to="/mycart" activeclassname="active">MyCart</NavLink>
        <NavLink to="/aboutus" activeclassname="active">AboutUs</NavLink>
        <NavLink to="/contactus" activeclassname="active">ContactUs</NavLink>
        <NavLink to="/logout" activeclassname="active">Logout</NavLink>
      </div>
    </nav>
  );
}
