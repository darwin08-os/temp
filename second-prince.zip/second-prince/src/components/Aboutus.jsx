import React from 'react';
import './aboutus.css';

export default function Aboutus() {
  return (
    <div className='about'>
      <div className="container">
        <h1>About Us</h1>
        <p>Welcome to <strong>LaptopShoppy</strong> — your trusted online destination for the latest laptops, gadgets, and accessories.</p>

        <p>Founded by <strong>Prince Kavar</strong>, our mission is to make technology accessible, affordable, and exciting for everyone. We handpick the finest products to ensure quality and reliability, while offering competitive prices and seamless service.</p>

        <p>At LaptopShoppy, we believe in blending innovation with tradition. Our dedicated team works tirelessly to bring you not just devices, but experiences that enhance your lifestyle and productivity.</p>

        <p>Thank you for choosing us as your tech partner. We promise to keep improving and evolving with you.</p>

        <div className="owner-sign">
          <p>Sincerely,</p>
          <h3>Prince Kavar</h3>
          <p className="title">Founder & CEO, LaptopShoppy</p>
        </div>
      </div>
    </div>
  );
}
