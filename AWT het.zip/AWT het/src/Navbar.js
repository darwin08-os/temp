import React from 'react';
import { Link } from 'react-router-dom';

function Navbar() {
  return (
    <nav className="navbar navbar-expand-lg navbar-light" style={{backgroundColor:"#5A8185"}}>
      <Link className='navbar-brand' href=''>
                <img src='pic/logo2.png' alt='logo' style={{width:"50px", height:"25px"}}/>
            </Link>
     
      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav mr-auto">
          <li className="nav-item">
            <Link to="/" className="nav-link">Home</Link>
          </li>
          <li className="nav-item">
            <Link to="/men" className="nav-link">Men</Link>
          </li>
          <li className="nav-item">
            <Link to="/women" className="nav-link">Women</Link>
          </li>
          </ul>
          <ul className='navbar-nav mr-2'>
          <li className='nav-item'>
            <Link className='nav-link' to="/mycart">MyCart</Link>
          </li>
         
          <li className="nav-item">
            <Link to="/aboutus" className="nav-link">AboutUs</Link>
          </li>
          <li className="nav-item">
            <Link to="/signup" className="nav-link">Sign Up</Link>
          </li>
        </ul>
      </div>
    </nav>
  );
}

export default Navbar;