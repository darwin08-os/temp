import Data from './Women.json';
export default function Women(props){
    const addToCart = (index) => {
        let curProduct = Data[index];
        alert(curProduct.title+" has been added to Cart.");
        props.purchaseItem(curProduct);
    }
    return(
        <>
        <h1 className='col-12 text-center'>All Products</h1>
        <div className='container'>
            <div className='row'>
                {Data.map((d,i)=>{
                    return(
                        <>
                        <div className='col-4 text-center' style={{marginBottom:"50px"}}>
                            <img src={d.url} alt='productImage' style={{height:"300px", width:"220px", }}/>
                            <br/>{d.title}
                            <br/>Rs. {d.price}/-
                            <br/><button className='btn btn-warning' onClick={()=>addToCart(i)}>Add To Cart</button>
                        </div>
                        </>
                    )
                })}
            </div>
        </div>
        <footer className="footer text-center mt-5">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <h3>About Us</h3>
              <p>
                At Your Store, we are dedicated to providing quality products and excellent service. With a team of passionate professionals, we strive to meet your fashion needs.
              </p>
            </div>
            <div className="col-md-6">
              <h3>Contact Information</h3>
              <p>Email: info@yourstore.com<br />Phone: +1 (123) 456-7890</p>
            </div>

          </div>
          <hr />
          <p>&copy; 2024 Your Store. All rights reserved.</p>
        </div>
      </footer>
        </>
    )
}