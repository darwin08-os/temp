import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function LoginForm() {
  const [formData, setFormData] = useState({ uname: "", pass: "" });
  const [errorMessages, setErrorMessages] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const navigate = useNavigate();

  const database = [
    { username: "user1", password: "pass1" },
    { username: "user2", password: "pass2" },
  ];

  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.name]: event.target.value });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    setIsLoading(true);

    const userData = database.find((user) => user.username === formData.uname);

    if (userData) {
      if (userData.password !== formData.pass) {
        setErrorMessages({ message: "Invalid username or password" });
      } else {
        // Redirect to the home page upon successful login
        navigate("/");
      }
    } else {
      setErrorMessages({ message: "Invalid username or password" });
    }

    setIsLoading(false);
  };

  return (
    <div style={styles.app}>
      <div style={styles.loginForm}>
        <div style={styles.title}>Sign In</div>
        {isLoading ? (
          <div>Loading...</div>
        ) : (
          <form onSubmit={handleSubmit} style={styles.form}>
            <div style={styles.inputContainer}>
              <label style={styles.label}>Username</label>
              <input
                type="text"
                name="username"
                value={formData.uname}
                onChange={handleChange}
                style={styles.input}
                required
              />
            </div>
            <div style={styles.inputContainer}>
              <label style={styles.label}>Password</label>
              <input
                type="password"
                name="password"
                value={formData.pass}
                onChange={handleChange}
                style={styles.input}
                required
              />
            </div>
            {errorMessages && <div style={styles.error}>{errorMessages.message}</div>}
            <div style={styles.buttonContainer}>
              <input type="submit" value="Submit" style={styles.submitButton} />
            </div>
          </form>
        )}
        <div style={styles.signupLink}>
          Don't have an account? <a href="/signup">Sign up</a>
        </div>
      </div>
    </div>
  );
}

// Styles

const styles = {
  app: {
    fontFamily: "sans-serif",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "column",
    gap: "20px",
    height: "100vh",
    backgroundColor: "#f8f9fd",
  },
  input: {
    height: "40px",
    border: "1px solid rgba(0, 0, 0, 0.2)",
    borderRadius: "4px",
    paddingLeft: "10px",
  },
  submitButton: {
    marginTop: "20px",
    cursor: "pointer",
    fontSize: "16px",
    background: "#01d28e",
    border: "1px solid #01d28e",
    color: "#fff",
    padding: "12px 24px",
    borderRadius: "4px",
  },
  buttonContainer: {
    display: "flex",
    justifyContent: "center",
  },
  loginForm: {
    backgroundColor: "white",
    padding: "2rem",
    boxShadow: "0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)",
    borderRadius: "8px",
    maxWidth: "400px",
    width: "100%",
  },
  error: {
    color: "red",
    fontSize: "14px",
    marginTop: "10px",
  },
  title: {
    fontSize: "25px",
    marginBottom: "20px",
    textAlign: "center",
  },
  inputContainer: {
    display: "flex",
    flexDirection: "column",
    gap: "16px",
    margin: "10px",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "20px",
  },
  label: {
    fontSize: "16px",
    marginBottom: "8px",
  },
  signupLink: {
    marginTop: "20px",
    fontSize: "14px",
    textAlign: "center",
  },
};

export default LoginForm;
