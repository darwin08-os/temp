// SignUpForm.jsx

import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function SignUpForm() {
  const [formData, setFormData] = useState({
    username: "",
    password: "",
    confirmPassword: "",
    email: "",
    dob: "", // Added dob to formData
  });
  const [errorMessages, setErrorMessages] = useState(null);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const navigate = useNavigate();

  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.name]: event.target.value });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    setIsLoading(true);

    // Your signup logic goes here

    // For demonstration purposes, assume signup is successful
    setIsSubmitted(true);

    setIsLoading(false);

    // Redirect to the home page
    navigate("/");
  };

  const renderErrorMessage = () =>
    errorMessages && <div style={styles.error}>{errorMessages.message}</div>;

  const renderForm = (
    <div style={styles.form}>
      <form onSubmit={handleSubmit}>
        <div style={styles.inputContainer}>
          <label style={styles.label}>Username</label>
          <input
            type="text"
            name="username"
            value={formData.username}
            onChange={handleChange}
            style={styles.input}
            required
          />
        </div>
        <div style={styles.inputContainer}>
          <label style={styles.label}>Email</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            style={styles.input}
            required
          />
        </div>
        <div style={styles.inputContainer}>
          <label style={styles.label}>DOB</label>
          <input
            type="text"
            name="dob"
            value={formData.dob}
            onChange={handleChange}
            style={styles.input}
            required
          />
        </div>
        <div style={styles.inputContainer}>
          <label style={styles.label}>Password</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            style={styles.input}
            required
          />
        </div>
        {renderErrorMessage()}
        <div style={styles.buttonContainer}>
          <input type="submit" value="Sign Up" style={styles.submitButton} />
        </div>
      </form>
      <div style={styles.loginLink}>
        Already have an account? <Link to="/login">Sign in</Link>
      </div>
    </div>
  );

  return (
    <div style={styles.signupApp}>
      <div style={styles.signupForm}>
        <div style={styles.title}>Sign Up</div>
        {isSubmitted ? (
          <div>Signup successful! You can go forward...!!</div>
        ) : (
          <>
            {isLoading ? <div>Loading...</div> : renderForm}
          </>
        )}
      </div>
    </div>
  );
}

const styles = {
  signupApp: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "column",
    gap: "20px",
    height: "100vh",
    backgroundColor: "#f8f9fd",
  },
  signupForm: {
    backgroundColor: "white",
    padding: "2rem",
    boxShadow: "0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)",
    borderRadius: "8px",
    maxWidth: "400px",
    width: "100%",
  },
  title: {
    fontSize: "25px",
    marginBottom: "20px",
    textAlign: "center",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "20px",
  },
  inputContainer: {
    display: "flex",
    flexDirection: "column",
    gap: "16px",
    margin: "10px",
  },
  label: {
    fontSize: "16px",
    marginBottom: "8px",
  },
  input: {
    height: "40px",
    border: "1px solid rgba(0, 0, 0, 0.2)",
    borderRadius: "4px",
    paddingLeft: "10px",
  },
  submitButton: {
    marginTop: "20px",
    cursor: "pointer",
    fontSize: "16px",
    background: "#01d28e",
    border: "1px solid #01d28e",
    color: "#fff",
    padding: "12px 24px",
    borderRadius: "4px",
  },
  buttonContainer: {
    display: "flex",
    justifyContent: "center",
  },
  error: {
    color: "red",
    fontSize: "14px",
    marginTop: "10px",
  },
  loginLink: {
    marginTop: "20px",
    fontSize: "14px",
    textAlign: "center",
  },
};

export default SignUpForm;
