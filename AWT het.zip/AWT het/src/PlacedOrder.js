import React from 'react';
import './PlacedOrder.css';
import { useNavigate } from 'react-router-dom';

export default function PlacedOrder() {
  const navigate = useNavigate();

  const handleContinueShopping = () => {
    navigate('/');
  };

  return (
    <div className="order-success">
      <div className="order-box">
        <div className="checkmark-container">
          <div className="checkmark">&#10004;</div>
        </div>
        <h2 className="order-title">Order Placed Successfully!</h2>
        <p className="order-message">Thank you for shopping with us. Your items will be delivered soon.</p>
        
        <div className="order-summary">
          <h4>Order Summary</h4>
          <p>Your order ID: <strong>#{Math.floor(100000 + Math.random() * 900000)}</strong></p>
          <p>We've sent a confirmation to your registered email.</p>
        </div>

        <button className="continue-btn" onClick={handleContinueShopping}>
          Continue Shopping
        </button>
      </div>
    </div>
  );
}
