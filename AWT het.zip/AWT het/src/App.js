import React from 'react';
import { useState } from "react";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';
import Navbar from './Navbar';
import Home from './Home';
import Women from './Women';
import Men from './Men';
import Login from './Login';
import MyCart from './mycart';
import AboutUs from './AboutUs';
import SignUpForm from './signup';
import Ckeckout from './Checkout';
import PlacedOrder from './PlacedOrder';

function App () {
  const [addedCart, setAddedCart] = useState([]);
  const addedFun = (item) => {
    let temp = [...addedCart,item];
    setAddedCart(temp);
  }
  const removeItem = (index) => {
    let temp = [...addedCart];
    temp.splice(index,1);
    setAddedCart(temp);
  }
  return (
    <Router>
      <Navbar />
      
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/men" element={<Men purchaseItem = {addedFun}/>} />
          <Route path="/women" element={<Women purchaseItem = {addedFun}/>} />
          <Route path="/mycart" element={<MyCart purchaseItem={addedCart} deleteItem={removeItem}/>}/>
          
          <Route path="/aboutus" element={<AboutUs />} />
          <Route path="/login" element={<Login />} />
          <Route path="/placedorder" element={<PlacedOrder />} />
          <Route path="/checkout" element={<Ckeckout />} />
          <Route path="/signup" element={<SignUpForm />} />
        </Routes>
  
    </Router>
  );
};

export default App;
