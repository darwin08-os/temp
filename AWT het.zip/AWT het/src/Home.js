import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

function Home() {
  const PrevArrow = (props) => {
    const { onClick } = props;
    return (
      <button onClick={onClick} className="slick-prev">
        Previous
      </button>
    );
  };

  const NextArrow = (props) => {
    const { onClick } = props;
    return (
      <button onClick={onClick} className="slick-next">
        Next
      </button>
    );
  };

  const carouselSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2700,  // Set the autoplay speed in milliseconds (3 seconds in this case)
    prevArrow: <PrevArrow />,
    nextArrow: <NextArrow />,
  };
  
  return (
    <div>
      <Slider {...carouselSettings}>
        <div>
          <img src="pic/slidebar1.webp" alt="Slide 1" className="d-block w-100" />
        </div>
        <div>
          <img src="pic/slidebar2.jpg" alt="Slide 1" className="d-block w-100" />
        </div>
        {/* Add more slides as needed */}
      </Slider>

      <br />
      <hr />

      <div className="container">
        <div className="title" style={{ display: 'flex', justifyContent: 'center' }}>
          <h2>Featured Products !</h2>
        </div>
        <div className="feature">
          {/* Featured Products */}
          <div className="card">
            <img src="pic/feature1.jpg" className="card-img-top" alt="Featured Product 1" style={{ height: "500px", width: "350px" }} />
            <div className="card-body">
              <h5 className="card-title">Featured Product 1</h5>
            </div>
          </div>
          <div className="card">
            <img src="pic/feature2.webp" className="card-img-top" alt="Featured Product 2" style={{ height: "500px", width: "350px" }} />
            <div className="card-body">
              <h5 className="card-title">Featured Product 2</h5>
            </div>
          </div>
          {/* Add more featured products if needed */}
        </div>
      </div>

      <footer className="footer text-center mt-5">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <h3>About Us</h3>
              <p>
                At Your Store, we are dedicated to providing quality products and excellent service. With a team of passionate professionals, we strive to meet your fashion needs.
              </p>
            </div>
            <div className="col-md-6">
              <h3>Contact Information</h3>
              <p>Email: info@yourstore.com<br />Phone: +1 (123) 456-7890</p>
            </div>
          </div>
          <hr />
          <p>&copy; 2024 Your Store. All rights reserved.</p>
        </div>
      </footer>

      <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
    </div>
  );
}

export default Home;
