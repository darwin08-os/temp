import React from 'react';

function AboutUs() {
  return (
    <div>
      <div className="container mt-5">
        <h2 className="text-center">About Us</h2>
        <hr />

        <div className="row mt-4">
          <div className="col-md-6">
            <h3>Our Story</h3>
            <p>
              At Your Store, we believe that fashion is a form of self-expression. Our journey began in 2010 with a vision to provide a platform for people to discover and embrace their unique style.
            </p>
            <p>
              Over the years, we have grown into a trusted fashion destination, offering a curated selection of the latest trends and timeless classics. Our commitment to quality, creativity, and customer satisfaction sets us apart in the world of fashion.
            </p>
          </div>

          <div className="col-md-6">
            <h3>Our Mission</h3>
            <p>
              Our mission is to empower individuals to express themselves through fashion. We strive to provide an inclusive and diverse shopping experience, catering to various styles, sizes, and preferences.
            </p>
            <p>
              With a team of dedicated professionals and a passion for fashion, we continue to evolve and adapt to the ever-changing landscape of the industry. Your journey with us is not just about buying clothes; it's about embracing your identity and celebrating your individuality.
            </p>
          </div>
        </div>
      </div>

      <footer className="footer text-center mt-5">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <h3>About Us</h3>
              <p>
                At Your Store, we are dedicated to providing quality products and excellent service. With a team of passionate professionals, we strive to meet your fashion needs.
              </p>
            </div>
            <div className="col-md-6">
              <h3>Contact Information</h3>
              <p>Email: info@yourstore.com<br />Phone: +1 (123) 456-7890</p>
            </div>
           
          </div>
          <hr />
          <p>&copy; 2024 Your Store. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default AboutUs;
