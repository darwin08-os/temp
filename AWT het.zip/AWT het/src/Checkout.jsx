import React, { useEffect, useState } from "react";
import './checkout.css';
import { useNavigate } from "react-router-dom";

export default function Checkout() {
  const [cartItems, setCartItems] = useState([]);
  const [total, setTotal] = useState(0);
const x = useNavigate()
  useEffect(() => {
    const storedItems = JSON.parse(localStorage.getItem("cartItems")) || [];
    setCartItems(storedItems);

    let sum = 0;
    for (let item of storedItems) {
      sum += item.price;
    }
    setTotal(sum);
  }, []);

  const handlePlaceOrder=()=>{
    x('/placedorder')
  }

  return (
    <div className="checkout-container">
      <h2>Checkout Page</h2>
      <div className="checkout-content">
        <div className="order-summary">
          <h3>Order Summary</h3>
          <table className="summary-table">
            <thead>
              <tr>
                <th>Product</th>
                <th>Price (Rs.)</th>
              </tr>
            </thead>
            <tbody>
              {cartItems.map((item, index) => (
                <tr key={index}>
                  <td>{item.title}</td>
                  <td>{item.price}</td>
                </tr>
              ))}
              <tr className="total-row">
                <td>Total</td>
                <td>{total}/-</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="user-form">
          <h3>Shipping Information</h3>
          <form>
            <label>Full Name</label>
            <input type="text" placeholder="John Doe" required />

            <label>Address</label>
            <input type="text" placeholder="123 Main St" required />

            <label>City</label>
            <input type="text" placeholder="City" required />

            <label>Zip Code</label>
            <input type="text" placeholder="123456" required />

            <label>Phone Number</label>
            <input type="text" placeholder="9876543210" required />

            <button type="submit" onClick={handlePlaceOrder}>Place Order</button>
          </form>
        </div>
      </div>
    </div>
  );
}
