import {react, useEffect, useState} from 'react'
import './mycart.css'
export default function MyCart(){

  const [laptop,setLaptop] = useState(JSON.parse(localStorage.getItem('laptopshoppy')))
  const [total,setTotal] = useState(0)


  const countTotal=()=>{
    let price = 0
    let pricearr = laptop.map((obj)=>{
      return obj.price * obj.quantity
    })
    for(let i=0; i < pricearr.length;i++){
      price += pricearr[i]
    }
    setTotal(price)
  }


  useEffect(()=>{
    if(localStorage.getItem('laptopshoppy')){
      let items =  JSON.parse(localStorage.getItem('laptopshoppy')) 
      setLaptop(items)
      countTotal()
    }
  },[localStorage.getItem('laptopshoppy')])

  return(
    <div className='mycart'>
    {!laptop? <p>add item first</p> :  
    <>
    <div className='mycart-content'>
      <div className='products'>
      {laptop.map((obj,index)=>{
        return <div key={index}>
          <img src={require(`.${obj.url}`)} width={'100px'} />
          <p>{obj.price}</p>
          <p>{obj.title}</p>
        </div>
      })}
      </div>
<div className='bill'>
  <p>bill</p>
  
  <table border={'1px solid black'} >
   
    <tr>
      <th></th>
      <th>Title</th>
      <th>Price</th>
      <th>Quantity</th>
    </tr>
    {laptop.map((obj,index)=>{
    return <>  <tr>
      <td>{index+1}</td>
      <td>{obj.title}</td>
      <td>{obj.price * obj.quantity}</td>
      <td>{obj.quantity}</td>
    </tr>
  </>
  
   })}
   <tr className='total'>
    <td colSpan={2}><b>Total Price </b></td>
    <td> <b> {total} </b> </td>
    <td></td>
  </tr>
  </table>
</div>
    </div>
 
</>


    }    
    </div>
    )
}