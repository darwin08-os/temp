import Navbar from './components/Navbar'
import './App.css';
import './components/login.css';
import Home from './components/Home'
import userData from '../src/userData.json'
import MyCart from './components/MyCart'
import Aboutus from './components/Aboutus'
import Logout from './components/Logout'
import Contactus from './components/Contactus'
import {BrowserRouter,Routes,Route, useAsyncError, useNavigate} from 'react-router-dom'
import { useState } from 'react';
function App() {

  
  const [login,isLogin] = useState(localStorage.getItem('login'))
  const [user,setUser] = useState({
    username : '',
    password : ''
  })

  const userset=(val)=>{
    setUser({...user,username : val})
  }
  const passset=(val)=>{
    setUser({...user,password : val})
  }
  const log=()=>{
    let Currentuser = userData.find((obj)=> obj.username == user.username && obj.username == user.username )
    if(Currentuser){
      localStorage.setItem('login',JSON.stringify(user))
      isLogin(true)
    }
     
  }
  const logout=()=>{
    localStorage.clear()
    isLogin(sessionStorage.getItem('login'))
    setUser({
      username : '',
      password : ''
    })
  }


  return (
    <div className="App">

    {login?   
    <BrowserRouter>
      <Navbar/>
      <Routes>
        <Route path='/' element={<Home />}/>
        <Route path='/mycart' element={<MyCart />}/>
        <Route path='/aboutus' element={<Aboutus />}/>
        <Route path='/contactus' element={<Contactus />}/>
        <Route path='/logout' element={<Logout logout={logout} />}/>
      </Routes>
      </BrowserRouter>
      :<>
      <div className="login">
        <input type="text" placeholder='username' className='form-control' value={user.username} onChange={(e)=>userset(e.target.value)} /> <br />
        <input type="password" placeholder='password' className='form-control' value={user.password} onChange={(e)=>passset(e.target.value)} />
      </div>
        <button type="button" className='btn btn-primary' onClick={log}>login</button>
      </>
  }
    </div>
  );
}

export default App;
